/**
 * popup.js - Displays recent scan history
 */

document.addEventListener('DOMContentLoaded', () => {
  const historyList = document.getElementById('history-list');

  chrome.storage.local.get('history', (data) => {
    const history = data.history || [];

    if (history.length === 0) {
      historyList.innerHTML = '<div class="empty">No pages scanned yet.</div>';
      return;
    }

    historyList.innerHTML = '';
    history.forEach(item => {
      const row = document.createElement('div');
      row.className = 'history-item';
      row.innerHTML = `
        <span class="domain">${item.domain}</span>
        <span class="risk-tag risk-${item.risk}">${item.risk}</span>
      `;
      historyList.appendChild(row);
    });
  });
});
