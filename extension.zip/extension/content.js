/**
 * content.js - Content Script for AntiScammer
 * Extracts page data and manages the UI sidebar via Shadow DOM.
 */

let analysisDebounceTimer = null;

// Initialize Shadow DOM for Sidebar
function injectSidebar() {
  if (document.getElementById('antiscammer-root')) return;

  const container = document.createElement('div');
  container.id = 'antiscammer-root';
  document.body.appendChild(container);

  const shadow = container.attachShadow({ mode: 'open' });
  
  // Link styles
  const styleLink = document.createElement('link');
  styleLink.rel = 'stylesheet';
  styleLink.href = chrome.runtime.getURL('sidebar.css');
  shadow.appendChild(styleLink);

  const sidebar = document.createElement('div');
  sidebar.id = 'antiscammer-sidebar';
  sidebar.className = 'sidebar-hidden';
  sidebar.innerHTML = `
    <div class="sidebar-header">
      <div class="malaysia-flag-bar"></div>
      <div class="header-main">
        <h3>AntiScammer AI</h3>
        <span id="confidence-score">98% Match</span>
      </div>
      <button id="close-sidebar" title="Shortcut: Esc">&times;</button>
    </div>
    <div id="sidebar-content">
      <div class="status-container">
        <div id="status-badge" class="badge-neutral">Scanning...</div>
        <div id="confidence-bar" class="confidence-bar">
          <div id="confidence-fill"></div>
        </div>
      </div>
      <div class="info-section">
        <label>Reason:</label>
        <p id="risk-reason">Analyzing page content...</p>
      </div>
      <div class="info-section">
        <label>Action:</label>
        <p id="user-action">Please wait while Gemini evaluates the page.</p>
      </div>
      <div class="actions">
        <button id="report-btn" class="secondary-btn">Laporkan Sekarang</button>
      </div>
    </div>
  `;
  shadow.appendChild(sidebar);

  // Keyboard shortcut listener (Esc key)
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      sidebar.classList.add('sidebar-hidden');
    }
  });

  // Event Listeners for Sidebar
  shadow.getElementById('close-sidebar').addEventListener('click', () => {
    sidebar.classList.add('sidebar-hidden');
  });

  shadow.getElementById('report-btn').addEventListener('click', () => {
    window.open('https://www.mcmc.gov.my/', '_blank'); // Example reporting link
  });

  return shadow;
}

const shadowRoot = injectSidebar();

function updateSidebar(result) {
  const sidebar = shadowRoot.getElementById('antiscammer-sidebar');
  const badge = shadowRoot.getElementById('status-badge');
  const reason = shadowRoot.getElementById('risk-reason');
  const action = shadowRoot.getElementById('user-action');
  const fill = shadowRoot.getElementById('confidence-fill');
  const score = shadowRoot.getElementById('confidence-score');

  sidebar.classList.remove('sidebar-hidden');
  
  badge.textContent = result.risk.toUpperCase();
  badge.className = `badge-${result.risk}`;
  
  reason.textContent = result.reason;
  action.textContent = result.action;
  
  fill.style.width = `${result.confidence}%`;
  fill.className = `fill-${result.risk}`;

  score.textContent = `${result.confidence}% Confidence`;
  score.className = `score-${result.risk}`;

  // Auto-hide if safe after 5 seconds, keep visible if danger/suspicious
  if (result.risk === 'safe') {
    setTimeout(() => {
      sidebar.classList.add('sidebar-hidden');
    }, 5000);
  }
}

function analyzePage() {
  const pageData = {
    url: window.location.href,
    title: document.title,
    text: document.body.innerText.substring(0, 2000),
    sensitiveFields: !!document.querySelector('input[type="password"], input[name*="card"], input[id*="card"]')
  };

  chrome.runtime.sendMessage({
    type: "ANALYZE_PAGE",
    data: pageData
  });
}

// Debounce logic
function triggerAnalysis() {
  if (analysisDebounceTimer) clearTimeout(analysisDebounceTimer);
  analysisDebounceTimer = setTimeout(analyzePage, 1000);
}

// Watch for changes
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "ANALYSIS_RESULT") {
    updateSidebar(message.result);
  } else if (message.type === "ANALYSIS_ERROR") {
    const sidebar = shadowRoot.getElementById('antiscammer-sidebar');
    const badge = shadowRoot.getElementById('status-badge');
    const reason = shadowRoot.getElementById('risk-reason');
    const action = shadowRoot.getElementById('user-action');

    sidebar.classList.remove('sidebar-hidden');
    badge.textContent = "NOTICE";
    badge.className = "badge-suspicious";
    reason.textContent = message.error;
    action.textContent = "AI scanning is currently limited but the extension will keep trying in the background.";
  }
});

// Start analysis on load
if (document.readyState === 'complete') {
  triggerAnalysis();
} else {
  window.addEventListener('load', triggerAnalysis);
}
