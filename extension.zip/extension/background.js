/**
 * background.js - Service Worker for AntiScammer
 * Handles Gemini 2.0 Flash API calls and state management.
 */

const GEMINI_MODEL = "gemini-2.0-flash";
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

// Hardcoded Malaysian Scam Domain Grounding (MCMC/PDRM patterns)
const SCAM_BLACKLIST = [
  "maybank2u-secure.net",
  "maybanksafety.com",
  "cimb-secure-login.top",
  "lhdn-tax-refund.org",
  "pdrm-check.online",
  "shopee-lucky-draw.com",
  "lazada-rewards.site",
  "tnb-ebilling.online",
  "epf-withdraw-service.info",
  "cleaning-vpp-malaysia.apk.download"
];

// Cache to prevent redundant scans across sessions or tabs
async function getCachedResult(url) {
  const { scanCache = {} } = await chrome.storage.local.get("scanCache");
  const cached = scanCache[url];
  if (cached && Date.now() - cached.timestamp < 24 * 60 * 60 * 1000) {
    return cached.result;
  }
  return null;
}

async function setCachedResult(url, result) {
  const { scanCache = {} } = await chrome.storage.local.get("scanCache");
  scanCache[url] = { result, timestamp: Date.now() };
  
  // Prune cache if it gets too big (keep last 50)
  const keys = Object.keys(scanCache);
  if (keys.length > 50) {
    delete scanCache[keys[0]];
  }
  
  await chrome.storage.local.set({ scanCache });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "ANALYZE_PAGE") {
    handleAnalysis(request.data, sender.tab.id);
    return true;
  }
});

async function handleAnalysis(data, tabId) {
  const { url, title, text } = data;
  const domain = new URL(url).hostname;

  try {
    // 0. Grounding check (RAG lite) - Save API quota
    const isBlacklisted = SCAM_BLACKLIST.some(d => domain.includes(d));
    if (isBlacklisted) {
      const blacklistedResult = {
        risk: "danger",
        confidence: 100,
        reason: "Matched known Malaysian scam domain from MCMC/PDRM threat intelligence reports.",
        action: "LEAVE IMMEDIATELY. This is a verified phishing or malware distribution site."
      };
      chrome.tabs.sendMessage(tabId, { type: "ANALYSIS_RESULT", result: blacklistedResult, isGrounded: true });
      return;
    }

    // 1. Check local cache first
    const cached = await getCachedResult(url);
    if (cached) {
      chrome.tabs.sendMessage(tabId, { type: "ANALYSIS_RESULT", result: cached, isCached: true });
      return;
    }

    const { geminiApiKey } = await chrome.storage.local.get("geminiApiKey");
    if (!geminiApiKey) {
      chrome.tabs.sendMessage(tabId, {
        type: "ANALYSIS_RESULT",
        result: {
          risk: "suspicious",
          confidence: 0,
          reason: "API Key missing. Please set it in the extension options.",
          action: "Open extension options to configure your Gemini API Key."
        }
      });
      return;
    }

    // ... systemInstruction and prompt variables remain the same ...
    const systemInstruction = `
      Act as a Malaysian Cybersecurity Analyst. Analyze the provided page context for:
      1. Phishing: Clones of Shopee, Lazada, Maybank2u, CIMB Clicks, or EPF/LHDN portals.
      2. APK Scams: Common in Malaysia (e.g., "Cleaning Services", "VPP", "PDRM" apps).
      3. Social Engineering: Unusual urgency, requests for TAC/OTP, "Investment" schemes involving "Tan Sri" figures, or suspicious Telegram links.
      Language: Support both Bahasa Malaysia and English.
      
      Constraint: Return ONLY a valid JSON object.
      Format: {"risk": "safe" | "suspicious" | "danger", "confidence": 0-100, "reason": "Short explanation in language of page", "action": "Advice for user"}.
    `;

    const prompt = `
      URL: ${url}
      Title: ${title}
      Content: ${text.substring(0, 2000)}
    `;

    const response = await fetch(`${API_URL}?key=${geminiApiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        systemInstruction: { parts: [{ text: systemInstruction }] },
        generationConfig: { responseMimeType: "application/json" }
      })
    });

    const resultData = await response.json();
    
    if (resultData.error) {
      let errorMessage = resultData.error.message;
      if (errorMessage.includes("quota")) {
        errorMessage = "Daily API limit reached. AI protection will resume tomorrow. Please check your Gemini API dashboard.";
      }
      throw new Error(errorMessage);
    }

    const aiResponse = JSON.parse(resultData.candidates[0].content.parts[0].text);
    
    // 2. Cache and Save History
    await setCachedResult(url, aiResponse);
    updateHistory(url, aiResponse.risk);

    // Send back to content script
    chrome.tabs.sendMessage(tabId, { type: "ANALYSIS_RESULT", result: aiResponse });

  } catch (error) {
    console.error("Analysis failed:", error);
    chrome.tabs.sendMessage(tabId, {
      type: "ANALYSIS_ERROR",
      error: error.message
    });
  }
}

async function updateHistory(url, risk) {
  const domain = new URL(url).hostname;
  const { history = [] } = await chrome.storage.local.get("history");
  
  // Remove existing entry for this domain to move it to the top
  const newHistory = [
    { domain, risk, timestamp: Date.now() },
    ...history.filter(item => item.domain !== domain)
  ].slice(0, 5); // Keep last 5

  await chrome.storage.local.set({ history: newHistory });
}
